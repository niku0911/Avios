var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/shipping': {
                'Nikunj_CheckoutCustomForm/js/view/shipping-mixin': true
            }
        }
    }
};